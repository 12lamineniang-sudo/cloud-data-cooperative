import json
import os
import time
import base64
import boto3
from datetime import datetime, timezone

# Endpoints pour LocalStack
localstack_host = os.environ.get('LOCALSTACK_HOSTNAME', 'localhost')
endpoint_url = f"http://{localstack_host}:4566"

dynamodb = boto3.resource('dynamodb', endpoint_url=endpoint_url)
s3 = boto3.client('s3', endpoint_url=endpoint_url)

MAPPING_TABLE = os.environ.get('MAPPING_TABLE')
DATA_STORE_BUCKET = os.environ.get('DATA_STORE_BUCKET')

def get_header_case_insensitive(headers, key):
    if not headers:
        return None
    for k, v in headers.items():
        if k.lower() == key.lower():
            return v
    return None

def lambda_handler(event, context):
    device_token = None
    content_type = "application/json"
    body_content = ""
    is_http = False

    if "headers" in event:
        is_http = True
        headers = event.get("headers", {})
        device_token = get_header_case_insensitive(headers, "device_token")
        content_type = get_header_case_insensitive(headers, "content-type") or "text/csv"
        
        raw_body = event.get("body", "")
        if event.get("isBase64Encoded", False):
            body_content = base64.b64decode(raw_body).decode('utf-8', errors='ignore')
        else:
            body_content = raw_body
    else:
        device_token = event.get("device_token")
        body_content = json.dumps(event.get("payload", event))

    if not device_token:
        if is_http:
            return {
                "statusCode": 401,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "Unauthorized", "message": "En-tête device_token manquant"})
            }
        return {"status": "rejected", "reason": "device_token manquant"}

    table = dynamodb.Table(MAPPING_TABLE)
    db_response = table.get_item(Key={"device_token": device_token})
    item = db_response.get("Item")

    if not item or not item.get("is_active", True):
        if is_http:
            return {
                "statusCode": 401,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "Unauthorized", "message": "Jeton d'appareil invalide ou non enregistré"})
            }
        return {"status": "rejected", "reason": "Jeton invalide"}

    department = item.get("department", "inconnu")
    device_id = item.get("device_id", "appareil_inconnu")

    now_utc = datetime.now(timezone.utc)
    date_path = now_utc.strftime('%Y/%m/%d')
    epoch_now = int(time.time())

    is_csv = "csv" in content_type.lower() or body_content.strip().startswith(("Station", "timestamp", "date", "Time", "sensor", "device"))
    ext = "csv" if is_csv else "json"
    s3_key = f"{department}/{date_path}/{epoch_now}_{device_id}.{ext}"

    s3.put_object(
        Bucket=DATA_STORE_BUCKET,
        Key=s3_key,
        Body=body_content,
        ContentType="text/csv" if is_csv else "application/json",
        Metadata={
            "device_id": device_id,
            "department": department,
            "ingested_at": now_utc.isoformat()
        }
    )

    result = {
        "status": "success",
        "message": f"Fichier {ext.upper()} accepté et stocké pour le département '{department}'",
        "device_id": device_id,
        "department": department,
        "s3_path": f"s3://{DATA_STORE_BUCKET}/{s3_key}"
    }

    if is_http:
        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(result)
        }
    return result
